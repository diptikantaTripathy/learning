$(document).ready(function() {
    $('#employeeTable').dataTable({
    	"bPaginate": false,
    	"bJQueryUI": true
    });
} );