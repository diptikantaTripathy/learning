package com.dstsystems.training.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;


@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class EmployeeEvaluation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="evaluation_seq")
	@SequenceGenerator(name="evaluation_seq", sequenceName="evaluation_id_seq", allocationSize=1)
	@Column(name="ID")
	private Long id;
	
	@XmlTransient
	@OneToOne
	@JoinColumn(name="EMPLOYEE_ID")
	private Employee employee;
	
	@Column(name="SUMMARY")
	private String summary;
	
	@Column(name="RATING")
	private BigDecimal rating;
	
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public BigDecimal getRating() {
		return rating;
	}
	public void setRating(BigDecimal rating) {
		this.rating = rating;
	}	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}
