package com.dstsystems.training.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dstsystems.training.entity.Employee;
import com.dstsystems.training.entity.EmployeeEvaluation;
import com.dstsystems.training.entity.EmployeeType;
import com.dstsystems.training.service.EmployeeEvaluationService;
import com.dstsystems.training.service.EmployeeService;

/**
 * Handles requests relating to employees.
 */
@Controller
@RequestMapping(value="/employees")
public class EmployeeController {
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private EmployeeEvaluationService evaluationService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getEmployeeList(Model model) {
		model.addAttribute("employeeList", employeeService.findAllEmployees());
		return "employeeList";
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String getEmployee(Model model, @PathVariable Long id) {
		model.addAttribute("employee", employeeService.findOneEmployee(id));
		return "employeeDetail";
	}	

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.GET)
	public String getEmployeeEdit(Model model, @PathVariable Long id) {
		model.addAttribute("employee", employeeService.findOneEmployee(id));
		return "employeeEdit";
	}
	
	@ModelAttribute("employeeTypes")
	public EmployeeType[] getEmployeeTypes() {
		return EmployeeType.values();
	}
	
	@RequestMapping(value = "/{id}/edit", method = RequestMethod.POST)
	public String saveEmployee(Employee employee, BindingResult result, Model model) {
		String viewName = "redirect:/employees";
		if(!result.hasErrors()) {
			employeeService.saveEmployee(employee);						
		}
		else {
			viewName = "employeeEdit";
		}
		return viewName;
	}
	
	@RequestMapping(value ="/{id}/evaluations", method = RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody EmployeeEvaluation getEmployeeEvaluations(@PathVariable Long id, Model model) {
		return evaluationService.findEvaluationForEmployee(id);
	}
}
