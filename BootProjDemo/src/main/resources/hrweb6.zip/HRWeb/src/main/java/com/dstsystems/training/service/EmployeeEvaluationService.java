package com.dstsystems.training.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dstsystems.training.entity.Employee;
import com.dstsystems.training.entity.EmployeeEvaluation;
import com.dstsystems.training.repository.EmployeeEvaluationRepository;
import com.dstsystems.training.repository.EmployeeRepository;

@Service
public class EmployeeEvaluationService {
	
	@Autowired
	private EmployeeEvaluationRepository employeeEvaluationRepository;
	
	public EmployeeEvaluation findEvaluationForEmployee(Long employeeId) {
		return this.employeeEvaluationRepository.findByEmployeeId(employeeId);
	}
	
}
