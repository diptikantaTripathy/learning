$(document).ready(function() {
	$("#evaluation").hide();
	$( "#employeeName" ).hover(function(){
		$.getJSON($("#internalEmployeeId").attr("value") + "/evaluation")
		.done(function(data) {
			var evaluation = data;
			$("#rating").text(evaluation.rating);
			$("#summary").text(evaluation.summary);
			$("#evaluation").show("slide", {}, 500, function() {
				setTimeout(function(){
					$("#evaluation").fadeOut();
				}, 3000);
			});
		}); 
	});
} );