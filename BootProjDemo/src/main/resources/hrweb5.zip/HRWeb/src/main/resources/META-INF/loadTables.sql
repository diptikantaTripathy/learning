INSERT INTO Employee
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	1, 
	'George', 
	'Washington', 
	'EID001', 
	'Chief Executive', 
	'Corporate', 
	'SALARIED',
	'1950-01-01');

INSERT INTO Employee
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	2, 
	'John', 
	'Adams', 
	'EID002', 
	'Vice President', 
	'Human Resources', 
	'SALARIED',
	'1961-02-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	3, 
	'Thomas', 
	'Jefferson', 
	'EID003', 
	'Chief Technology Officer', 
	'Information Technology', 
	'CONTRACT',
	'1971-03-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	4, 
	'James', 
	'Madison', 
	'EID004', 
	'Customer Relationship Manager', 
	'Sales', 
	'SALARIED',
	'1981-04-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	5, 
	'James', 
	'Monroe', 
	'EID005', 
	'Customer Representative', 
	'Sales', 
	'SALARIED',
	'1991-01-01');
	
INSERT INTO EmployeeEvaluation 
(	ID, 
	EMPLOYEE_ID, 
	SUMMARY, 
	RATING)
values
(	1, 
	1, 
	'George is a model leader. He has presence. He is dignified and honest (almost to a fault).
	He is tough, too. He recently squashed a rebellion of sorts in our Pennsylvania division.', 
	5.0);	