package com.dstsystems.training.entity;

public enum EmployeeType {
	
	SALARIED("S", "Salaried"),
	HOURLY("H", "Hourly"),
	PART_TIME("P", "Part-Time"),
	CONTRACT("C", "Contract");
	
	private String value;
	private String display;
	
	EmployeeType(String value, String display) {
		this.value = value;
		this.display = display;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public String getDisplay() {
		return this.display;
	}

}
