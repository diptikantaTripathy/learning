package com.dstsystems.training.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.dstsystems.training.entity.Employee;
import com.dstsystems.training.entity.EmployeeEvaluation;

public interface EmployeeEvaluationRepository extends CrudRepository<EmployeeEvaluation, Long> {
	
	@Query("Select x from EmployeeEvaluation x WHERE x.employee.id = :employeeId")
	public EmployeeEvaluation findByEmployeeId(@Param("employeeId") Long employeeId);
	
}
