$(document).ready(function() {
	$( "#birthDate" ).datepicker();
} );