package com.dstsystems.training.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dstsystems.training.entity.Employee;
import com.dstsystems.training.entity.EmployeeType;
import com.dstsystems.training.service.EmployeeService;

/**
 * Handles requests relating to employees.
 */
@Controller
@RequestMapping(value="/employees")
public class EmployeeController {
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getEmployeeList(Model model) {
		model.addAttribute("employeeList", employeeService.findAllEmployees());
		return "employeeList";
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public String getEmployee(Model model, @PathVariable Long id) {
		model.addAttribute("employee", employeeService.findOneEmployee(id));
		return "employeeDetail";
	}	

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.GET)
	public String getEmployeeEdit(Model model, @PathVariable Long id) {
		model.addAttribute("employee", employeeService.findOneEmployee(id));
		return "employeeEdit";
	}
	
	@ModelAttribute("employeeTypes")
	public EmployeeType[] getEmployeeTypes() {
		return EmployeeType.values();
	}
	
	@RequestMapping(value = "/{id}/edit", method = RequestMethod.POST)
	public String saveEmployee(Employee employee, Model model) {
		String viewName = "redirect:/employees";
		employeeService.saveEmployee(employee);			
		return viewName;
	}
}
