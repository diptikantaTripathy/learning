INSERT INTO Employee
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	1, 
	'George', 
	'Washington', 
	'EID001', 
	'Chief Executive', 
	'Corporate', 
	'SALARIED',
	'1950-01-01');

INSERT INTO Employee
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	2, 
	'John', 
	'Adams', 
	'EID002', 
	'Vice President', 
	'Human Resources', 
	'SALARIED',
	'1961-02-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	3, 
	'Thomas', 
	'Jefferson', 
	'EID003', 
	'Chief Technology Officer', 
	'Information Technology', 
	'SALARIED',
	'1971-03-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	4, 
	'James', 
	'Madison', 
	'EID004', 
	'Customer Relationship Manager', 
	'Sales', 
	'SALARIED',
	'1981-04-01');

INSERT INTO Employee 
(	ID, 
	FIRST_NAME, 
	LAST_NAME, 
	EMPLOYEE_ID, 
	TITLE, 
	DEPARTMENT, 
	EMPLOYEE_TYPE, 
	BIRTH_DATE)
values
(	5, 
	'James', 
	'Monroe', 
	'EID005', 
	'Customer Representative', 
	'Sales', 
	'SALARIED',
	'1991-01-01');