package com.dstsystems.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dstsystems.training.entity.Employee;
import com.dstsystems.training.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Iterable<Employee> findAllEmployees() {
		return this.employeeRepository.findAll();
	}
	
	public Employee findOneEmployee(Long id) {
		return this.employeeRepository.findOne(id);
	}
	
	public void saveEmployee(Employee employee) {
		employeeRepository.save(employee);
	}

}
