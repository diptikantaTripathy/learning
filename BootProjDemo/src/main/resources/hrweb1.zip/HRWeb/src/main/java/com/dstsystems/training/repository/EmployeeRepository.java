package com.dstsystems.training.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.dstsystems.training.entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	
	@Query("Select x from Employee x WHERE x.lastName LIKE concat(:lastName, '%')")
	public Collection<Employee> findByLastNameLike(@Param("lastName") String lastName);
	
}
